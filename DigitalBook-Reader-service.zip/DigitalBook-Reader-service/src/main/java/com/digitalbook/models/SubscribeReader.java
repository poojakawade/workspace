package com.digitalbook.models;
import java.util.ArrayList;

public class SubscribeReader {

	private int subId;
	private int bookId;
	Reader reader;
	public int getSubId() {
		return subId;
	}
	public void setSubId(int subId) {
		this.subId = subId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public Reader getReader() {
		return reader;
	}
	public void setReader(Reader reader) {
		this.reader = reader;
	}
	public SubscribeReader() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SubscribeReader(int subId, int bookId, Reader reader) {
		super();
		this.subId = subId;
		this.bookId = bookId;
		this.reader = reader;
	}
	
	
	
	

}
