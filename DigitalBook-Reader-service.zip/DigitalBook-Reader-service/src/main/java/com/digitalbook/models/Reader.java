package com.digitalbook.models;

public class Reader {

	private int readerId;
	private String name;
	private String email;
	
	public int getReaderId() {
		return readerId;
	}
	public void setReaderId(int readerId) {
		this.readerId = readerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Reader() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Reader(String name, String email) {
		super();
		this.name = name;
		this.email = email;
	}
	
	

}
