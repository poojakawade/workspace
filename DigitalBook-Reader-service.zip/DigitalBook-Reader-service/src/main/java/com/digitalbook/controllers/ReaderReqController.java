package com.digitalbook.controllers;

import java.util.List;

import org.hibernate.internal.CriteriaImpl.Subcriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.digitalbook.clients.BookServiceClient;
import com.digitalbook.models.Book;
import com.digitalbook.models.Subscribe;

@RestController
@RequestMapping("/api/v1/digitalbooks/readers")
public class ReaderReqController {

	@Autowired
	private BookServiceClient bookServiceClient;

	@GetMapping("/{emailID}/books")
	public List<Book> getBooksbyemailID(@PathVariable String emailID) {
		return bookServiceClient.getBooksbyemailID(emailID);
	}
	
	@GetMapping("/{emailID}/books/{bookId}")
	public List<Book> getBooksbyemailIDnbookID(@PathVariable String emailID,@PathVariable int bookId) {
		return bookServiceClient.getBooksbyemailIDnbookID(emailID,bookId);
	}
	
	@PostMapping("/{emailID}/books")
	public List<Book> getBooksbypayId(@PathVariable String emailID,@RequestParam int payId) {
		return bookServiceClient.getBooksbypayId(emailID,payId);
	}
	
	@PostMapping("/{emailID}/books/{bookId}/refund")
	public String getRefund(@PathVariable String emailID,@PathVariable int bookId) {
		return bookServiceClient.getRefund(emailID,bookId);
	}


}
