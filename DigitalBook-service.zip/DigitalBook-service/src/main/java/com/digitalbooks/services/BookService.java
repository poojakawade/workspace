package com.digitalbooks.services;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalbooks.entities.Book;
import com.digitalbooks.entities.Subscribe;
import com.digitalbooks.exception.BookServiceException;
import com.digitalbooks.repositories.BookServiceRepository;
import com.digitalbooks.repositories.SubscribeBookServiceRepository;

@Service
public class BookService {

	@Autowired
	private BookServiceRepository repo;
	@Autowired
	private SubscribeBookServiceRepository srepo;

	public List<Book> getAllBooks() {
		return repo.findAll();
	}

	public List<Book> findBycategoryAndauthorAndpriceAndpublisher(String category, String author, double price,
			String publisher) {
		String status = "Active";
		return repo.findByCategoryAndAuthorAndPriceAndPublisherAndStatus(category, author, price, publisher, status);
	}

	public Book getBookById(int bookid) throws BookServiceException {
		Optional<Book> optional = repo.findById(bookid);

		if (optional.isEmpty()) {
			throw new BookServiceException("Book not found with id: " + bookid);
		} else {
			return optional.get();
		}
	}

	public Book saveBook(Book book) {
		return repo.save(book);
	}

	public Book updateBook(Book book) throws BookServiceException {
		if (repo.existsById(book.getId())) {
			return repo.save(book);
		} else {
			throw new BookServiceException("Book not updated with Id: " + book.getId());
		}

	}

	public Subscribe subscribeBook(Subscribe sreader) throws BookServiceException {
		String emailID=sreader.getReaderEmail();
		int bookid=sreader.getBookId();
		if(srepo.ifExists(emailID, bookid)>0) {
			throw new BookServiceException("This book is already subcribed by user:"+emailID);
		}else {
			return srepo.save(sreader);
		}
	}

	public List<Book> getBooksbyemailID(String emailID) {
		return repo.findbookbyemailID(emailID);
	}

	public List<Book> getBooksbyemailIDnbookID(String emailID, int bookId) throws BookServiceException {

		List<Book> optional = repo.getBooksbyemailIDnbookID(emailID, bookId);

		if (optional.isEmpty()) {
			throw new BookServiceException("Book not found with id: " + bookId + " and emailId: " + emailID);
		} else {
			return repo.getBooksbyemailIDnbookID(emailID, bookId);
		}
	}

	public List<Book> getBooksbypayId(String emailID, int payId) throws BookServiceException {

		List<Book> optional = repo.getBooksbypayId(emailID, payId);

		if (optional.isEmpty()) {
			throw new BookServiceException("Book not found with id: " + payId + " and emailId: " + emailID);
		} else {
			return repo.getBooksbypayId(emailID, payId);
		}
	}

	public String getRefund(String emailID, int bookId) throws BookServiceException {

		LocalDateTime datetime = repo.getRefund(emailID, bookId);
		LocalDateTime now = LocalDateTime.now();  
		Duration duration = Duration.between(now, datetime);
	    long diff = Math.abs(duration.toSeconds());
	    System.out.println("diff:"+diff);
	    if(diff<=86400) {
			int id = repo.getkeyId(emailID, bookId);
			if (srepo.existsById(id)) {
				repo.updateRefund(id);
				return "Rufund is successful";
			}else {
				return "This book is non refundable as it exceeded it's predefined time limit";

		    }
	    }else {
			return "This book is non refundable as it exceeded it's predefined time limit";

	    }

	    

//		if (optional.isEmpty()) {
//			//throw new BookServiceException("Book not found with id: " + bookId + " and emailId: " + emailID);
//			return "This book is non refundable as it exceeded it's predefined time limit";
//		} else {
//			return "Rufund is successful";
//		}
	}

	/*
	 * public Book delete(int bookId) throws BookServiceException { Optional<Book>
	 * optional = repo.findById(bookId);
	 * 
	 * if (optional.isEmpty()) { throw new
	 * BookServiceException("Book not found with id: " + bookId); } else {
	 * repo.deleteById(bookId); return optional.get(); } }
	 */

}
