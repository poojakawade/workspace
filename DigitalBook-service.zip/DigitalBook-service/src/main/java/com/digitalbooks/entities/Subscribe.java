package com.digitalbooks.entities;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;

@Entity
public class Subscribe {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int bookId;
	private String readerName;
	private String readerEmail;
	private LocalDateTime datetime;
	private String refund;
	
	@PrePersist
	private void onCreate() {
		datetime= LocalDateTime.now();
		refund="N";
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getReaderName() {
		return readerName;
	}
	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}
	public String getReaderEmail() {
		return readerEmail;
	}
	public void setReaderEmail(String readerEmail) {
		this.readerEmail = readerEmail;
	}
	public LocalDateTime getDatetime() {
		return datetime;
	}
	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}
	public String getRefund() {
		return refund;
	}
	public void setRefund(String refund) {
		this.refund = refund;
	}

	public Subscribe(int bookId, String readerName, String readerEmail) {
		super();
		this.bookId = bookId;
		this.readerName = readerName;
		this.readerEmail = readerEmail;
		this.datetime = LocalDateTime.now();
		this.refund="N";
	}
	public Subscribe() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Subscribe [id=" + id + ", bookId=" + bookId + ", readerName=" + readerName + ", readerEmail="
				+ readerEmail + ", datetime=" + datetime + ", refund=" + refund + "]";
	}
	

}
