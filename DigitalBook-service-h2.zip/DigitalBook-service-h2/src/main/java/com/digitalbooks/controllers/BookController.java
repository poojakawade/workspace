package com.digitalbooks.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbooks.entities.Book;
import com.digitalbooks.entities.SubscribeReader;
import com.digitalbooks.exception.BookServiceException;
import com.digitalbooks.services.BookService;

@RestController
// @CrossOrigin(origins = {"https://hoppscotch.io"})
@CrossOrigin
@RequestMapping("/api/v1/digitalbooks")
public class BookController {

	@Autowired
	private BookService service;

	@GetMapping("/books")
	public List<Book> getAllBooks() {
		return service.getAllBooks();
	}

	@GetMapping("/books/searchbybooks")
	public List<Book> getBooks(@RequestParam String category, @RequestParam String author, @RequestParam double price,
			@RequestParam String publisher) {
		return service.findBycategoryAndauthorAndpriceAndpublisher(category, author, price, publisher);
	}

	@PostMapping("/savebooks")
	public Book saveBook(@RequestBody Book book) {
		return service.saveBook(book);
	}

	@PutMapping("/update")
	public Book updateBook(@RequestBody Book book) throws BookServiceException {
		return service.updateBook(book);
	}

	@PostMapping("/subscribe")
	public SubscribeReader subcribeBook(@RequestBody SubscribeReader sreader) {
		return service.subscribeBook(sreader);
	}
	/*
	 * @DeleteMapping("/books/{bookId}") public Book delete(@PathVariable int
	 * bookId) throws BookServiceException { return service.delete(bookId); }
	 */

}
