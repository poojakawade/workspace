package com.digitalbooks.entities;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class SubscribeReader {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int subId;
	private int bookId;
	@OneToMany(fetch = FetchType.EAGER,targetEntity = Reader.class,mappedBy = "readerId")
	private Reader reader;
	public int getSubId() {
		return subId;
	}
	public void setSubId(int subId) {
		this.subId = subId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public Reader getReader() {
		return reader;
	}
	public void setReader(Reader reader) {
		this.reader = reader;
	}
	public SubscribeReader() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SubscribeReader(int bookId, Reader reader) {
		super();
		this.bookId = bookId;
		this.reader = reader;
	}
	
	
	
	
	
	

}
